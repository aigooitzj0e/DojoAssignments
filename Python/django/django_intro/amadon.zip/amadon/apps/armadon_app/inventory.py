items = [
    {
    "id": 1,
    "name": "AK-47",
    "price": 899,
    },
    {
    "id": 2,
    "name": "Rocket Launcher",
    "price": 1399,
    },
    {
    "id": 3,
    "name": "Fake Passport",
    "price": 499,
    },
    {
    "id": 4,
    "name": "Goats",
    "price": 199,
    },
]
