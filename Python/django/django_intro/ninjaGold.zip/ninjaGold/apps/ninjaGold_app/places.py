

items = [
    {
    "id": 1,
    "name": "Farm",
    "chance": "(Earn 10-20 Gold)",
    "start": 10,
    "end": 20,
    },
    {
    "id": 2,
    "name": "Cave",
    "chance": "(Earn 5-10 Gold)",
    "start": 5,
    "end": 10,
    },
    {
    "id": 3,
    "name": "House",
    "chance": "(Earn 2-5 Gold)",
    "start": 2,
    "end": 5,
    },
    {
    "id": 4,
    "name": "Casino",
    "chance": "(Earn/Lose 0-50 Gold)",
    "start": -50,
    "end": 50,
    },
]
