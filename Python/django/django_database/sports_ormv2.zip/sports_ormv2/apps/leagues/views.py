from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"baseball_league": League.objects.filter(sport = 'Baseball'),
		"womens_league": League.objects.filter(name__contains="Women"),
		"hockey_league": League.objects.filter(sport__contains = "Hockey"),
		"conference": League.objects.filter(name__contains = "Conference"),
		"atlantic": League.objects.filter(name__contains = "Atlantic"),
		"dallas": Team.objects.filter(location = "Dallas"),
		"raptors": Team.objects.filter(team_name = "Raptors"),
		"city": Team.objects.filter(location__contains = "City"),
		"NamebeginsT": Team.objects.filter(team_name__contains = "T"),
		"alphabetically": Team.objects.order_by("team_name"),
		"revalphabetically": Team.objects.order_by("-team_name"),
		"last_name_cooper": Player.objects.filter(last_name = "Cooper"),
		"first_name_joshua": Player.objects.filter(first_name = "Joshua"),
		"first_name_alex": Player.objects.filter(first_name__in = ["Alexander", "Wyatt"]),
		"atlantic_soccer_conf": Team.objects.filter(league__name = "Atlantic Soccer Conference"),
		"current_players": Player.objects.filter(curr_team__team_name = "Penguins"),
		"x1": Player.objects.filter(curr_team__league__name = "International Collegiate Baseball Conference"),
		"x2": Player.objects.filter(curr_team__league__name = "American Conference of Amateur Football").filter(last_name="Lopez"),
		"x3": Player.objects.filter(curr_team__league__sport = "Football"),
		"x4": Team.objects.filter(curr_players__first_name = "Sophia"),
		"x5": Player.objects.filter(last_name = "Flores").exclude(curr_team__team_name = "Washington Roughriders"),
		"x6": Team.objects.filter(all_players__first_name__contains = "Samuel").filter(all_players__last_name__contains = "Evans"),
		"x7": Player.objects.filter(all_teams__team_name = "Tiger-Cats"),
		"x8": Player.objects.filter(all_teams__team_name = "Vikings").exclude(curr_team__team_name = "Vikings"),
		"x9": Team.objects.filter(all_players__first_name = "Jacob").filter(all_players__last_name = "Gray"),
		# "z1": Player.objects.filter(all_teams__league__name = "Atlantic Federation of Amateur Baseball").filter(first_name = "Joshua"),
		"z1": Player.objects.filter(first_name="Joshua").filter(all_teams__league__name="Atlantic Federation of Amateur Baseball Players"),
		"z2": Team.objects.all().annotate(player_count=Count('all_players')).filter(player_count__gte=12),
		"z3": Player.objects.all().annotate(team_count=Count('all_teams')).order_by('-team_count'),


	}
	return render(request, "leagues/index.html", context)

def make_data(rArithmeticErrorequest):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
